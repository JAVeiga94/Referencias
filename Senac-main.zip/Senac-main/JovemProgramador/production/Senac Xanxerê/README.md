# Senac
Repositório dedicado às atividades e projetos realizados com os alunos do SENAC Santa Catarina, nos cursos de desenvolvimento de games, jovem programador e lógica de programação.
