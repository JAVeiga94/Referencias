package Atividades.src.com.sharkdays.atividadeMetodos;

public class Metodos1 {


    public static void adicao(int x, int y){

        System.out.println(x + y);

    }
    public static void divisao(int x, int y){

        System.out.println(x / y);

    }
    public static void multiplicacao(int x, int y){

        System.out.println(x * y);

    }
    public static void subtracao(int x, int y){

        System.out.println(x - y);

    }

    public static void main(String[] args) {

        adicao(10, 10);
        divisao(10, 10);
        multiplicacao(10, 10);
        subtracao(10, 10);

    }

}
