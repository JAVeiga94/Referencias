package Atividades.src.com.sharkdays;

public class Variaveis {
    public static void main(String[] args) {

        final int meuNumero = 15;
        System.out.println(meuNumero);

        int myNum;
        myNum = 15;
        System.out.println(myNum);



        int Ademir = 2;
        if (Ademir >= 2){
            System.out.println(Ademir);
        }

//
//        final int myNum = 15;
//        myNum = 20;  // will generate an error: cannot assign a value to a final variable
//
//        int myNum = 5;
//        float myFloatNum = 5.99f;
//        char myLetter = 'D';
//        boolean myBool = true;
//        String myText = "Hello";
//
//        int x = 5;
//        int y = 6;
//        System.out.println(x + y); // Print the value of x + y
//
//// Good
//        int minutesPerHour = 60;
//
//// OK, but not so easy to understand what m actually is
//        int m = 60;
//

    }
}
