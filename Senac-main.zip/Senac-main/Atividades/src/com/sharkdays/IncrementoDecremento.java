package Atividades.src.com.sharkdays;

public class IncrementoDecremento {
    public static void main(String[] args) {
        int n = 100;

        System.out.println(n); // Imprime 100.
        System.out.println(n++); // Imprime 100.
        System.out.println(n); // Imprime 101.
    }
}
