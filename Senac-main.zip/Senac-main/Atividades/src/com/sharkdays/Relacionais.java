package Atividades.src.com.sharkdays;

public class Relacionais {
    public static void main(String[] args) {


        // Atividade 1:
//        int nota1 = 10;
//        int nota2 = 8;
//        int nota3 = 7;
//        int nota4 = 5;
//
//        int media = (nota1 + nota2 + nota3 + nota4) / 4;
//        System.out.println(media);
//
//        if (media >= 7){
//            System.out.println("Aprovado!");
//        }
//        else{
//            System.out.println("Reprovado!");
//        }


        // Atividade 2:

//        Scanner Numero = new Scanner(System.in);
//
//        System.out.println("Entre com um valor para descobrir se é par ou ímpar: ");
//
//        int valor = Numero.nextInt();
//
//        if (valor % 2 == 0){
//            System.out.println("Par!");
//        }
//        else{
//            System.out.println("Ímpar!");
//        }

        // Atividade 3:

//        Scanner Numero = new Scanner(System.in);
//
//        System.out.println("Entre com um valor para descobrir se ele está na faixa de 1 a 9: ");
//
//        int valor = Numero.nextInt();
//
//        if (valor > 0 && valor < 10){
//                System.out.println("Está na faixa.");
//            }
//            else{
//                System.out.println("Não está na faixa.");
//            }
//

        // Atividade 4:

//        Scanner Numero = new Scanner(System.in);
//
//        System.out.println("Entre com um valor para descobrir se ele é diferente de 1,2,3,4,5,6,7,8: ");
//
//        int valor = Numero.nextInt();
//
//        if (valor != 1 && valor != 2 && valor != 3 && valor != 4 && valor != 5 && valor != 6 && valor != 7 && valor != 8){
//                System.out.println("É diferente!");
//            }
//            else{
//                System.out.println("É igual!");
//            }

        // Atividade 5:
//
//        Scanner Numero = new Scanner(System.in);
//
//        System.out.println("Entre com o valor do lado 1 do triângulo: ");
//
//        double lado1 = Numero.nextDouble();
//
//        System.out.println("Entre com o valor do lado 2 do triângulo: ");
//
//        double lado2 = Numero.nextDouble();
//
//        System.out.println("Entre com o valor do lado 3 do triângulo: ");
//
//        double lado3 = Numero.nextDouble();
//
//        if (lado1 == lado2 && lado2 == lado3 && lado1 == lado3){
//
//            System.out.println("Triângulo Equilátero!");
//
//        }if ((lado1 == lado2 && lado3 != lado1) || (lado1 == lado3 && lado2 != lado1) || (lado3 == lado2 && lado3 != lado1)){
//
//            System.out.println("Triângulo Isóceles!");
//
//        }
//
//        if (lado1 != lado2 && lado2 != lado3 && lado1 != lado3){
//
//            System.out.println("Triângulo Escaleno!");
//
//        }


    }
}
