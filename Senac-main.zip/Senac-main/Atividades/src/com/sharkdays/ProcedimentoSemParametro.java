package Atividades.src.com.sharkdays;

import javax.swing.*;

public class ProcedimentoSemParametro {
    public static void mostrarMensagem(){
        JOptionPane.showMessageDialog(null, "Atividades");
    }

    public static void main(String[] args) {

        mostrarMensagem();

    }
}
