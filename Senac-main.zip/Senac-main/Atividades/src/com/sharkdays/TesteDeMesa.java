package Atividades.src.com.sharkdays;

public class TesteDeMesa {
    public static void main(String[] args) {

        // Atividade 1: MÉDIA

        float a,b,media;

        a = 10;
        b = 20;

        media = (a+b)/2;

        System.out.println(media);


        //Atividade 2: DIVISÃO

//        double a,b,c,soma,resultado;
//
//        a = 100;
//        b = 300;
//        c = 2;
//
//        soma = a + b;
//        resultado = soma / c;
//
//        System.out.println(resultado);

        //Atividade 3: MÉDIA COMPLEXA

//        double a1,a2,a3,a4,a5,a6,a7,a8,resultado;
//
//        a1 = 1.5;
//        a2 = 3.0;
//        a3 = a2 + a1;
//        a4 = a3 * 0.6;
//
//        if(a4>2){
//            a5 = 5.5;
//        }else{
//            a5 = 5.0;
//        }
//
//        a6 = 9.0;
//        a7 = a5 + a6;
//        resultado = a7 * 0.4;
//
//        System.out.println(resultado);

        //Atividade 4: PARES

//        int contador;
//
//        for (contador = 2; contador < 11; contador++ ){
//            if (contador % 2 == 0){
//                System.out.println(contador + " É par!");
//            }else{
//                System.out.println(contador + " É ímpar!");
//            }
//        }


        //Atividade 5: ENQUANTO

//        int a,b,c,contador;
//        contador = 1;
//        a = 1;
//        c = 1;
//
//        while(a < 10){
//            contador = contador + 1;
//            if (a == 11){
//                b = 5;
//            }
//            a = a + 1;
//            c = c + a * 2;
//
//        }

        //Atividade 6: CONDICIONAL

//        int a,b, contador1, contador2, c,x;
//
//        a = 1;
//        b = 2;
//
//        for (contador1 = 0; contador1 < 4; contador1++){
//            for (contador2 = 0; contador2 < 4; contador2++){
//                System.out.println(contador1 + " " + contador2);
//                a = contador1 + contador2 + a;
//                System.out.println(a);
//            }
//            b = a + 2 * b;
//                if (b > 15){
//                    c = a + b;
//                    System.out.println(c);
//                }else{
//                    c = a + b * 3;
//                    System.out.println(c);
//                }
//        }

    }
}
