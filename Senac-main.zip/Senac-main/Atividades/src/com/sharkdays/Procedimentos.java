package Atividades.src.com.sharkdays;

public class Procedimentos {

    public static void imprimirEscola(){
        System.out.println("Eu estudo no SENAC!");
    }

    public static void imprimirCidade(){
        System.out.println("Eu moro em Xanxerê!");
    }

    public static void main(String[] args) {
    imprimirEscola();
    imprimirCidade();
    }
}

