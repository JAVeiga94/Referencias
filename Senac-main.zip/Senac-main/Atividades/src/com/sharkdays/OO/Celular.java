package Atividades.src.com.sharkdays.OO;

public class Celular {
    private String fabricante;
    private String armazenamentoInterno;
    private int numeroDeCameras;

    public String getFabricante() {
        return fabricante;
    }

    public void setFabricante(String fabricante) {
        this.fabricante = fabricante;
    }

    public String getArmazenamentoInterno() {
        return armazenamentoInterno;
    }

    public void setArmazenamentoInterno(String armazenamentoInterno) {
        this.armazenamentoInterno = armazenamentoInterno;
    }

    public int getNumeroDeCameras() {
        return numeroDeCameras;
    }

    public void setNumeroDeCameras(int numeroDeCameras) {
        this.numeroDeCameras = numeroDeCameras;
    }

}
