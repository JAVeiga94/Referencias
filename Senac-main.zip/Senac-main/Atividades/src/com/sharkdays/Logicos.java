package Atividades.src.com.sharkdays;

public class Logicos {
    public static void main(String[] args) {

        //Atividade 4:
//        Scanner Idade = new Scanner(System.in);
//
//        System.out.println("Entre com um valor para descobrir se é maior ou menor de idade: ");
//
//        int valor = Idade.nextInt();
//
//        if (valor >= 18){
//            System.out.println("Maior de Idade!");
//        }
//        else{
//            System.out.println("Menor de Idade!");
//        }

        //Atividade 5
//
//
//       int masculino = 0;
//       int feminino = 0;
//
//       Scanner Entrada = new Scanner(System.in);
//       ArrayList lista = new ArrayList();
//
//       for (int i = 0; i < 5; i++){
//
//            System.out.println("Entre com o nome da pessoa:");
//
//            String nome = Entrada.next();
//
//            System.out.println("Sexo 1 para Masculino ou 2 para Feminino:");
//
//            int sexo = Entrada.nextInt();
//
//            lista.add(nome);
//
//            if (sexo == 1) {
//
//                masculino++;
//
//            }
//
//           else if (sexo == 2){
//
//               feminino++;
//
//           }
//        }
//
//        System.out.println(lista);
//        System.out.println("Quantidade de Homens é: " + masculino + "\nQuantidade de Mulheres é: " + feminino);

        }
    }

