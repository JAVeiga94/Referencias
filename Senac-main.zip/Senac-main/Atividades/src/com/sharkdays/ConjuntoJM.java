package Atividades.src.com.sharkdays;

public class ConjuntoJM {
    public static void main(String[] args) {

//    // Tipo    Nome        Valor
//        String nome1 = "Rogerio";
//        String nome2 = " Juliano";
//        String nome3 = " Wendel";
//        System.out.println(nome1 + nome2 + nome3);

        String tamanho = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
        System.out.println("The length of the txt string is: " + tamanho.length());

//        String txt = "Hello World";
//        System.out.println(txt.toUpperCase());   // Outputs "HELLO WORLD"
//        System.out.println(txt.toLowerCase());   // Outputs "hello world"

//          String txt = "Please locate where 'locate' occurs!";
//          System.out.println(txt.indexOf("locate")); // Outputs 7
//
//          String firstName = "John";
//          String lastName = "Doe";
//          System.out.println(firstName + " " + lastName);

//            String firstName = "John ";
//            String lastName = "Doe";
//            System.out.println(firstName.concat(lastName));

 //         String txt = "We are the so-called "Vikings" from the north.";

//        String x = "10";
//        int y = 20;
//        String z = x + y;   // z will be 1020 (a String)





    }

}
