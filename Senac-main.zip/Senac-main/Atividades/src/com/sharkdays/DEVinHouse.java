package Atividades.src.com.sharkdays;

public class DEVinHouse {
    public static void main(String[] args) {
            int x = -10;
            while(x++ != 0){
                System.out.println(x);
            }
    }
}
