package main.java.org.example;

public class ParOuImpar {
    public static boolean verificarParOuImpar(int numero) {
        return numero % 2 == 0;
    }
}
