package Aulas.src;

public enum PedidoStatus {
    PAGAMENTO_PENDENTE,
    PROCESSANDO,
    ENVIADO,
    ENTREGUE;
}
