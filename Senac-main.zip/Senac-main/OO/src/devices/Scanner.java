package devices;

public interface Scanner {
    String scan();
}
