package entities;

import entities.enums.Color;

public interface Shape {
	public abstract double area();
}
