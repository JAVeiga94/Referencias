[Link do README do trabalho](https://github.com/MatheusMelloDev/Tabalho-de-React-Native-App/blob/main/README.md)
