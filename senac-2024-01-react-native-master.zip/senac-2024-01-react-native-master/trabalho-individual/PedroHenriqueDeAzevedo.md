<header>
  <h2>Link do repositório do trabalho</h2>
  <h3>Autor: Pedro Henrique de Azevedo</h3>
</header>
<main>
  <div>
    Link do respositório do aplicativo clone: https://github.com/Pedro-Wong/ReactNative_appClone
  </div>
</main>
