https://github.com/miguelmilagres/crunchyroll-clone
