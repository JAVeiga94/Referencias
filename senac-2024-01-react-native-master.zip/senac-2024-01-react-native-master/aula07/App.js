import 'react-native-gesture-handler';
import Rotas from './src/routes';

export default function App() {
  return (
      <Rotas />
  );
}
