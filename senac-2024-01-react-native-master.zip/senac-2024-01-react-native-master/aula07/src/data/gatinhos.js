export const gatinhos = [
    {
      "id": "10h",
      "url": "https://cdn2.thecatapi.com/images/10h.jpg",
      "width": 480,
      "height": 640
    },
    {
      "id": "2lv",
      "url": "https://cdn2.thecatapi.com/images/2lv.png",
      "width": 500,
      "height": 333
    },
    {
      "id": "2re",
      "url": "https://cdn2.thecatapi.com/images/2re.jpg",
      "width": 375,
      "height": 500
    },
    {
      "id": "a01",
      "url": "https://cdn2.thecatapi.com/images/a01.jpg",
      "width": 1723,
      "height": 2571
    },
    {
      "id": "e28",
      "url": "https://cdn2.thecatapi.com/images/e28.jpg",
      "width": 747,
      "height": 478
    },
    {
      "id": "MTUxMTkxNg",
      "url": "https://cdn2.thecatapi.com/images/MTUxMTkxNg.jpg",
      "width": 600,
      "height": 400
    },
    {
      "id": "MjA1NzUyMg",
      "url": "https://cdn2.thecatapi.com/images/MjA1NzUyMg.jpg",
      "width": 414,
      "height": 231
    },
    {
      "id": "fhYh2PDcC",
      "url": "https://cdn2.thecatapi.com/images/fhYh2PDcC.jpg",
      "width": 700,
      "height": 466
    },
    {
      "id": "VXppGG5rK",
      "url": "https://cdn2.thecatapi.com/images/VXppGG5rK.jpg",
      "width": 1250,
      "height": 650
    },
    {
      "id": "xIICfnlNm",
      "url": "https://cdn2.thecatapi.com/images/xIICfnlNm.jpg",
      "width": 1696,
      "height": 2544
    }
  ]